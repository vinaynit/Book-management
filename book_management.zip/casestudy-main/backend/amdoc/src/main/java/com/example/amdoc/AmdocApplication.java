package com.example.amdoc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmdocApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmdocApplication.class, args);
	}

}
