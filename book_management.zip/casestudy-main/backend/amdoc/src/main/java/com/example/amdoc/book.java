package com.example.amdoc;

public class book 
{
private String book_id;
private String book_Name;
private String author;
private int price;
public String getBook_id() {
	return book_id;
}

public void setBook_id(String book_id) {
	this.book_id = book_id;
}

public String getBook_Name() {
	return book_Name;
}

public void setBook_Name(String book_Name) {
	this.book_Name = book_Name;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}

public String getAuthor() {
	return author;
}

public void setAuthor(String author) {
	this.author = author;
}

}

